# include<stdio.h>

int main()
{
    int QT= 3;
    int QS= 4;
    int QC= 2;
    float P1= 60.00;
    float P2= 40.50;
    float P3= 120.00;
    double pta = QT * P1;
    double psa = QS * P2;
    double pca = QC * P3; 
    double GST = 0.16 * ST;
    double FPA = ST + GST;
    double st = pca + pta + psa;
    double gst = .16 * st;
    double gt = gst + st;
 
    printf("FAST CAFETERIA RECEIPT\n");
    printf("Item\t\tQty\t\tUnitPrice(PKR)\t\tSubtotal(PKR)\n");
    printf("Tea\t\t\t %d\t\t%.2f\t\t\t\t\t%.2f\n", QT , P1 , pta );
    printf("Samosa\t\t %d\t\t%.2f\t\t\t\t\t%.2f\n", QS , P2 , psa );
    printf("Chicken Roll %d\t\t%.2f\t\t\t\t\t%.2f\n", QC , P3 , pca );
    printf("Subtotal   :\t\t\t\t\t\t\t\t\tPKR %.2f\n", st);
    printf("GST   (16%):\t\t\t\t\t\t\t\t\tPKR %.2f%%\n", gst);
    printf("Grand Total : \t\t\t\t\t\t\tPKR %.2f\n", gt);
    printf("THANK YOU FOR YOUR VISIT ");
    return 0;

}