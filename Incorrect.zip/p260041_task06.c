#include<stdio.h>

int main()
{
 float radius=7.5;
 float pi=3.141590;
 float Diameter= 2*radius;
 float Circumference=2*pi*radius;
 float Area=radius*radius;
 printf("Given radius: %.3f\n"radius,);
 printf("Calculated Diameter: %.3f\n",Diameter);
 printf("Calculated Circumference: %.3f\n",Circumference);
printf("Calculated Area: %.3f\n",Area);
 return 0;
}
