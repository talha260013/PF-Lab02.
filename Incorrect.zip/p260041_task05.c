#include<stdio.h>

int main()
{
 float Celsius=37.5;
 float Fahrenheit=(Celsius*9.0/5.0)+32.0;
 float Kelvin=Celsius+273.15;
 printf("Temperature in Celsius: %.2f\n"Celsius,);
 printf("Temperature in Fahrenheit: %.2f\n",Fahrenheit);
 printf("Temperature in Kelvin: %.2f\n",Kelvin);
 return 0;
}
