#include<stdio.h>

int main()
{
 double Basic_Salary=85000.00;
 float house_Rent_Allowance=(0.20*Basic_Salary);
 float Medical_Allowance=(0.10*Basic_Salary);
 float Gross_Salary=Basic_Salary+house_Rent_Allowance+Medical_Allowance;
 float Tax_Reduction=(0.5*Gross_Salary);
 float Net_Salary=Gross_Salary-Tax_Reduction;
 printf("Basic Salary: %.2f\n",Basic_Salary);
 printf("house Rent Allowance: %.2f\n",house_Rent_Allowance);
 printf("Medical_Allowance: %.2f\n",Medical_Allowance);
 printf("Gross Salary: %.2f\n",Gross_Salary);
 printf("Tax Reduction: %.2f\n",Tax_Reduction);
 printf("Net Salary: %.2f\n",Net_Salary);
 return 0;
}
 