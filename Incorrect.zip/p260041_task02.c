#include<stdio.h>

int main()
{
 int Batch_Year= 2026;
 char Section= 'A';
 float Test_Score= 65.50;
 double Semester_Fee= 52000;
 printf("Batch Year: %d\n",Batch_Year);
 printf("Section: %c\n",Section);
 printf("Test Score: %.2f\n",Test_Score);
 printf("Semester Fee: %.1f\n",Semester_Fee); 
 return 0;
}

