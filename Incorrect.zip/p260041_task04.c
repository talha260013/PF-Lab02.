#include<stdio.h>

int main()
{
 char letter='M';
 int number= 42;
 float pi= 3.141590;
 double n= 98.765432;
 printf("char\t%c\t\t%zu byte\n",letter,sizeof(char));
 printf("int\t%d\t\t%zu byte\n",number,sizeof(int));
 printf("float\t%f\t\t%zu byte\n",pi,sizeof(float));
 printf("double\t%f\t\t%zu byte\n",n,sizeof(double));
 return 0;
}