#include<stdio.h>

int main()
{
 # include<stdio.h>
int main()
{    
  float Programming_Fund = 88.00;
  float Calculas= 76.50;
  float Applied_Physics = 82.00;
  float CH1 = 3;
  float CH2 = 3;
  flaot CH3 = 2;

  double Total_Weighted_Score = (88.0 * 3) + (76.5 * 3) + (82.0 * 2);
  double Total_Cradit_Hours= 8;
  double Weightege_Average_Percentage = Total_Weighted_Score/Total_Cradit_Hours;
    

    printf("SEMESTER ACADEMIC REPORT\n");
    printf("COURSE\t\t\tCREDIT HOURS\t\t\tOBTAINED MARKS\n");
    printf("Programming Fund\t\t\t%d\t\t\t\t\t\%.2f\n", CH1 , Programming_Fund);
    printf("Calculas\t\t\t\t%d\t\t\t\t\t%.2f\n", CH2 , Calculas);
    printf("Applied Physics\t\t\t%d\t\t\t\t\t%.2f\n", CH3 , Applied_Physics);
    printf("Total Credit Hours : %d \t\t\t\tWeighted Average:\t%.2f%%\n",Total_Cradit_Hours ,Weightege_Average_Percentage);
    return 0;
}