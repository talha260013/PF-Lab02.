#include<stdio.h>
 
int main()
{
 printf("To print a double quote,write:\\\"\n");
 printf("To print a literal backslash,write:\\\\\n");
 printf("To insert a newline break,write:\\n\n");
 printf("To insert a horizontal tab stop,write:\\t\n");
 printf("To print a percent sign,write:%%%%\n");
 return 0;
}