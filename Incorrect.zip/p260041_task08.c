#include<stdio.h>

int main()
{
 double Principal_Amount=250000.0;
 float rate=8.5;
 int Loan_Duration=3;
 float I=(Principal*rate*Loan_Duration)/100.0;
 float Total_Payable_Amount= Principal+I;
 float Monthly_Instalment=A/(Loan_Duration*12.0);
 printf("Principal Amount: %.1f",Principal_Amount);
 printf("Annual Interest Rate: %.1f",rate);
 printf("Loan Duration: %d",Loan_Duration);
 printf("Total Payable Amount: %.1f",Total_Payable_Amount);
 printf("MonthlyI nstalment: %.1f",Monthly_Instalment);
 return 0;
}
 